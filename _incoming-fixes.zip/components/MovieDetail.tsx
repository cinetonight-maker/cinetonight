import Link from "next/link";
import Image from "next/image";
import Icon from "./Icon";
import PlayButton from "./PlayButton";
import WatchlistButton from "./WatchlistButton";
import TicketStub from "./TicketStub";
import BlogSection from "./BlogSection";
import CommentsSection from "./CommentsSection";
import type { Movie } from "@/lib/types";
import { personId } from "@/lib/data";
import { personTmdbId } from "@/lib/tmdb";
import { posterLg, profile, backdrop } from "@/lib/images";

const PLATFORMS: [string, string, string][] = [
  ["Disney+ Hotstar", "Subscription", "#1f80e0"], ["JioCinema", "Subscription", "#c026d3"],
  ["Prime Video", "Rent / Buy", "#00a8e1"], ["YouTube", "Rent / Buy", "#ff0000"], ["Google Play", "Rent / Buy", "#34a853"],
];

function Det({ rows }: { rows: [string, string][] }) {
  return <>{rows.map(([k, v]) => (
    <div className="det" key={k}><span className="det__k">{k}</span><span className="det__v">{v}</span></div>
  ))}</>;
}

export default function MovieDetail({ movie }: { movie: Movie }) {
  const stars = movie.cast.slice(0, 3).map((c) => c.name).join(", ") || "—";
  const isSeries = movie.kind === "series";

  const detCols: [string, string][][] = [
    [["Director", movie.director], ["Writers", movie.writers], ["Stars", stars]],
    [["Language", movie.language], ["Country", "India"], ["Type", isSeries ? "Web Series" : "Feature Film"]],
    [["Runtime", movie.runtime], ["Certification", movie.cert], ["Genres", movie.genres.join(", ") || "—"]],
  ];
  const infoCards: [string, string, string][] = [
    ["cam", "Quality", "1080p / 4K"], ["vol", "Audio", movie.language],
    ["cc", "Subtitles", `${movie.language}, English`], ["cal", "Release Year", String(movie.year)],
  ];
  const minfo: [string, string][][] = [
    [["Release Year", String(movie.year)], ["Runtime", movie.runtime], ["Language", movie.language], ["Certification", movie.cert]],
    [["Genres", movie.genres.join(", ") || "—"], ["Country", "India"], ["Director", movie.director], ["Writers", movie.writers]],
    [["Type", isSeries ? "Web Series" : "Feature Film"], ["Rating", `${movie.rating.toFixed(1)} / 10`], ["Cast", `${movie.cast.length} credited`], ["Also Known As", movie.title]],
  ];
  const about = [
    movie.desc,
    `Directed by ${movie.director}, ${movie.title} leans on a strong ensemble — ${stars} — to carry a story that balances spectacle with character.`,
    `${isSeries ? "The series" : "The film"} landed with audiences for its craft and performances, and remains one of the most talked-about ${(movie.genres[0] ?? "screen").toLowerCase()} titles of ${movie.year}.`,
  ];

  return (
    <>
      <div className="crumb">
        <Link href="/">Home</Link><span className="sep">›</span>
        <Link href={isSeries ? "/web-series" : "/movies"}>{isSeries ? "Web Series" : "Movies"}</Link><span className="sep">›</span>
        <span className="cur">{movie.title}</span>
      </div>

      <section className="dhero">
        <div className="dposter">
          <Image fill alt={`${movie.title} poster`} src={posterLg(movie)} sizes="(max-width: 900px) 40vw, 300px" priority />
          <WatchlistButton id={movie.id} variant="save" />
        </div>
        <div>
          <h1 className="dtitle">{movie.title}</h1>
          <div className="dmeta">
            <span>{movie.year}</span><span>•</span><span>{movie.runtime}</span><span>•</span>
            {movie.genres.length > 0 && <><span>{movie.genres.join(", ")}</span><span>•</span></>}<span className="cert">{movie.cert}</span>
          </div>
          <div className="drate">
            <div className="drate__n"><Icon name="star" size={16} /> {movie.rating.toFixed(1)}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span className="imdb-badge">IMDb</span><span className="votes">User rating</span>
            </div>
            <div className="score">User Score <div className="ring"><span>{Math.round(movie.rating * 10)}%</span></div></div>
          </div>
          <p className="dsyn">{movie.desc}</p>
          <div className="dbtns">
            <PlayButton movie={movie} mode="watch" />
            <WatchlistButton id={movie.id} />
            <PlayButton movie={movie} label="Trailer" icon="playc" className="btn btn--ghost" mode="trailer" />
            <TicketStub movie={movie} />
          </div>
          <div className="dgrid">{detCols.map((rows, i) => <div key={i}><Det rows={rows} /></div>)}</div>
        </div>
      </section>

      <div className="infocards">
        {infoCards.map(([i, k, v]) => (
          <div className="infocard" key={k}>
            <span className="infocard__ic"><Icon name={i} size={20} /></span>
            <div><div className="infocard__k">{k}</div><div className="infocard__v">{v}</div></div>
          </div>
        ))}
      </div>

      <section className="sec">
        <div className="sec__head"><h2>Where to Watch</h2></div>
        <div className="railwrap"><div className="rail">
          {PLATFORMS.map(([n, k, c]) => (
            <div className="plat" key={n}>
              <div className="plat__logo" style={{ background: `color-mix(in srgb,${c} 20%,#15151f)`, color: c, border: `1px solid color-mix(in srgb,${c} 45%,transparent)` }}>{n[0]}</div>
              <div className="plat__name">{n}</div><div className="plat__kind">{k}</div>
              <PlayButton movie={movie} className="plat__btn" mode="trailer" />
            </div>
          ))}
        </div></div>
        <div className="plat-note">Availability may vary by region and platform.</div>
      </section>

      <section className="sec">
        <div className="sec__head"><h2>Cast</h2></div>
        <div className="railwrap"><div className="rail castrail">
          {movie.cast.map((c) => (
            // Prefer the TMDB-id route when we have one (works for cast on
            // both local-catalogue and live-fetched titles); fall back to
            // the name-slug route, which only resolves for people who
            // appear in the local catalogue (see app/person/[id]/page.tsx).
            <Link className="castc" href={`/person/${c.tmdbId ? personTmdbId(c.tmdbId) : personId(c.name)}`} key={c.name}>
              <div className="castc__ph"><Image fill alt={c.name} src={profile(c)} sizes="64px" /></div>
              <div className="castc__n">{c.name}</div>
              <div className="castc__r">as {c.character}</div>
            </Link>
          ))}
        </div></div>
      </section>

      <section className="sec">
        <div className="sec__head"><h2>Movie Info &amp; Details</h2></div>
        <div className="minfo">{minfo.map((rows, i) => <div key={i}><Det rows={rows} /></div>)}</div>
      </section>

      <section className="sec">
        <div className="sec__head"><h2>About {movie.title}</h2></div>
        <div className="about">
          <div className="about__body">
            {about.map((p, i) => <p key={i}>{p}</p>)}
            <Link className="about__btn" href="/blog">Read More on the Blog <Icon name="chevr" size={15} /></Link>
          </div>
          <div className="about__img"><Image fill alt={`${movie.title} backdrop`} src={backdrop(movie, "w780")} sizes="(max-width: 900px) 100vw, 380px" /></div>
        </div>
      </section>

      <CommentsSection movie={movie} />

      {/* The sidebar already has a compact BlogWidget, but the sidebar is
          hidden below 1200px (see .pageaside), which left mobile visitors
          with no blog content at all on this page. */}
      <BlogSection count={3} />
    </>
  );
}
